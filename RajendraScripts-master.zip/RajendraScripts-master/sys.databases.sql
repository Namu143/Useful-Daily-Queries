SELECT 
  SERVERPROPERTY('BuildClrVersion') AS BuildClrVersion,
  SERVERPROPERTY('ProductLevel') AS ProductLevel,
  SERVERPROPERTY('ProductVersion') AS ProductVersion,
--Hi, Adding a new comment in the Ram branch

--Adding a new feature for the branch 